# 实战踩坑集（生成器与画布层）

> 本册沉淀**真实踩过的坑**，每条都给出症状 → 根因 → 修法。
> 与 `SKILL.md` 的规范条款不同，这里记的是「规范没写、但一定会再犯」的经验。
> 触发场景：写 `build_*.py` 生成器、排查页面异常、做 3× 特写复核时读本册。

---

## 一、字符串注入层（本项目最隐蔽的一类坑）

产物 HTML 是用 Python 脚本把 LaTeX / JS 代码**注入模板**生成的。注入这一层出错，
症状统一表现为「页面看着正常，但公式渲染成 `Math input error`」，极易误判为公式写错。

### 1.1 `re.sub` 的替换串会吞反斜杠 ⚠⚠ 头号坑

**症状**：某个 `mjx-container` 渲染失败，其 SVG 宽度异常窄（`width="16ex"`），
assistive-MML 下出现 `<merror>`。逐条单测 `STEPS.tex` 全部干净 —— 说明公式本身没错。

**根因**：`re.sub(pattern, 替换串, out)` 会把替换串里的 `\b` `\d` `\t` `\f` `\Delta`
当成**反向引用 / 转义**处理，反斜杠被直接吞掉：

| 想注入 | 实际进入 JS | MathJax 收到 |
|---|---|---|
| `O_1=\big(` | `O_1=(` | `big` 命令丢失 |
| `\Delta t` | `Delta t` | 变成三个字母 |
| `\dfrac{1}{2}` | `dfrac{1}{2}` | — |

**修法（强制）**：**所有 `re.sub` 的替换串一律用 `lambda m: payload` 包一层**。

```python
# ✅ 正确：lambda 返回，payload 原样插入
out = _re.sub(r'const STEPS = \[[\s\S]*?\n\];', lambda m: steps_js.rstrip('\n'), out, count=1)

# ❌ 错误：裸字符串当替换串，反斜杠被吞
out = _re.sub(r'const STEPS = \[[\s\S]*?\n\];', steps_js, out, count=1)
```

### 1.2 Python `%r` / `repr()` 不能转义反斜杠

```python
repr('a\\Db')   # => "'a\\Db'"  ← 反斜杠仍未转义，JS 会把 \D 当转义序列
```
**修法**：写进 JS 源码的字符串字面量**统一走 `json.dumps(ensure_ascii=False)`**，
它与 JS 字面量语法完全兼容。

### 1.3 产物级硬门禁（务必加进生成器尾部）

比 Playwright 更早定位问题，且能直接指出是注入层坏了：

```python
_bad = []
for _m in _re.finditer(r'tex: "((?:[^"\\]|\\.)*)"', _out):
    _t = _m.group(1)
    if _re.search(r'(?<!\\)\\[A-Za-z]', _t):   # 单反斜杠 + 字母 = 危险
        _bad.append(_t[:70])
if _bad:
    for _b in _bad: print('BAD  单反斜杠: %s' % _b)
    raise SystemExit('反斜杠被吞：re.sub 替换串未用 lambda 包一层')
```

### 1.4 裸尖括号会破坏 HTML 结构

`\(z=0<z_0\)` 里的裸 `<` 被浏览器当标签起始 ⇒ 定界符配对失败 ⇒ 裸定界符门禁 FAIL。
**修法**：一律写 `\lt` / `\gt`。

### 1.5 `\mathrm{}` 不能放中文

`\mathrm{合}` ⇒ MathJax 报错。**修法**：用 `\text{合}`（`\mathrm` 只收字母）。

### 1.6 note 字段走 `innerHTML`，不解析 Markdown

模板用 `innerHTML` 插入 note，**`**加粗**` 会原样显示**。**修法**：直接写 `<b>加粗</b>`。

### 1.7 `ctx.fillText` 的坐标是屏幕像素，不是世界坐标

```js
// ❌ 把世界坐标当屏幕像素 ⇒ 文字落到画布 (0.8px, 0.3px) 处被裁，
//    表现为「画布顶端一条被裁掉的残字」，常被误判为上一帧残影
ctx.fillText('结论…', 0.80, 0.30);

// ✅ 凡按世界坐标定位的文字（含结论句、说明句）必须先过 W2S
ctx.fillText('结论…', W2S(0.86, 0.30)[0], W2S(0.86, 0.30)[1]);
```
> 诊断线索：**残字固定出现在画布左上角** ⇒ 一定是坐标体系用错，不是重影问题。

### 1.8 路径数组必须多 push 一个哨兵

分段几何的 `OFF`/`IDX` 类数组，只 push 每段起点（长度 = 段数）时，
最后一段取 `OFF[i+1]` 为 `undefined` ⇒ 插值返回 `NaN` ⇒ **该段绘制整体静默消失**。

```python
# 症状：红色「已走轨迹」在 t≥某时刻后整段不见了，只剩灰色虚线
# 修法（构造循环外补哨兵）：
PATH_OFF.push(FULL_PATH.length);
```

---

## 二、画布尺寸与 dpr

### 2.1 拿画布尺寸必须用 CSS 像素

```js
// ❌ canvas.width/height 是设备像素。框架已 setTransform(ratio,…)，
//    后续绘制坐标全按 CSS 像素解释 ⇒ 居中/靠右算出来会放大 2 倍、画到画布外
const W = ctx.canvas.width;

// ✅
const r = ctx.canvas.getBoundingClientRect();
const w = r.width, h = r.height;
```
> 症状：**只在 dpr=2 时出现**，表现为「横幅只露左半截」「HUD 整块消失」。
> **新写 HUD/横幅前先 `grep ctx.canvas.width`。**
> 另外不能用全局 `W/H`：`drawStaticGraph` 会临时改 `ctx`。

### 2.2 模板 `clearBg()` 在 dpr>1 时清不干净

模板原实现按 `canvas.width/height`（设备像素）清屏，而 `resize` 已 `setTransform(ratio,…)`
⇒ 顶部约 `H/ratio` 的条带永远残留上一帧。**修法**（就地覆盖模板函数）：

```js
function clearBgCss(){
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);              // ① 复位后按设备像素全清
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.restore();
  const _r = ctx.canvas.getBoundingClientRect();  // ② 再按 CSS 像素铺白
  const w = (_r && _r.width) ? _r.width : ctx.canvas.width;
  const h = (_r && _r.height) ? _r.height : ctx.canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
}
```
> ⚠ **模板修了不会自动回填历史 HTML**：改完 `assets/template.html`
> 必须跑 `scripts/patch_processbanner.py` 扫全部已产出文件。

### 2.3 画布顶部有「禁区」

`processBanner` 固定占 y=8~37 px，HUD 从 `42*k` 起、高 `(14+15n)*k`。
三栏下 H≈321、PAD=36 ⇒ **sy≈108 px 即 HUD 下沿**，世界坐标 `y > 0.50` 的标注必被遮。

**判据**：先反算 sy 像素位置，再放标签 —— **别凭感觉试**。

### 2.4 HUD 不能写死像素高度

三栏下画布宽仅 395~590 px、高 0.66×宽，必须按比例定位再反算 `VIEW.ymax`。

### 2.5 底部图例 ≥4 项必须多行

单行时 `iw = lw/n` 不足 ⇒ 文字互相重叠。**4 项改 2 列 × 2 行**，
字号 ≥10 px，标记与文字偏移按项宽重算。**图例自底向上要倒序。**

### 2.6 比例尺：等比例尺判据

`yrange/xrange` 须等于该画布**实际内宽**下的理想纵比 `(0.66·W内−72)/(W内−72)`。
三栏取 0.60 最稳；单栏恒 680 px ⇒ 0.6196。
**判据**：`W2S` 描点的弧会不会变椭圆。

---

## 三、作用域与 TDZ

| 坑 | 症状 | 修法 |
|---|---|---|
| 绘图/HUD 函数放进 `readouts` 体内 | 播放时 `ReferenceError`，rAF 不再排期 ⇒ **动画卡死 t=0**（`distinctFrames=1`） | 绘图函数必须放 `GLOBALS` |
| 派生常量写在 `GEO` 之前 | `Cannot access 'GEO' before initialization` ⇒ 整页中断（题干空白 + 无题图 + 空白画布，**易误判成模板问题**） | 引用 `GEO` 的常量写在 `GEO` 之后 |
| 非 `__GLOBALS__` 区放声明 | 语法错误 | 那三区在**函数体内**，只能放语句 |

> `__CANVAS_STATIC__` 孪生题图 = `drawSceneBody(0)`，
> 任何「元素没跟参考系平移」的 bug 都会暴露 —— 善用。

---

## 四、标注定位（本项目最耗时的一类）

### 4.1 运动体会扫过固定标注 ⇒ 必须暴力搜索安全区

先用 `scripts/probe_start_label.py` 算「全程离所有障碍 ≥N px」的区域，**不要凭感觉试**。
若邻域内无解 ⇒ 唯一解是**引线标注**（文字放空白区 + 细点线连回，颜色淡、短划，
避免像工程尺寸线）。

### 4.2 静态文字与运动粒子必冲突

粒子每次跨界面都会经过固定标注的锚点。**加隐藏判据**比反复挪位置可靠：

```js
const nearIface = (st.phase !== 'q3') && (Math.abs(st.z - PAR.z0) < 0.16);
drawKeyLabels(st, nearIface);   // 此判据下隐藏会被压住的引线标注，结论交由 HUD 承载
```

### 4.3 声波/光束的「定向锥角虚线」——已致缺陷两次

从波源向波前两端拉锥角虚线，参数（波前半径）变大后会变成**斜穿场景的长虚线**，
看起来像多余的工程辅助线。

**结论：新题一律不画锥角**，改用「主波前 + 内侧渐淡残影弧」，
方向用弧顶的短小 `→`/`←` 箭头表示。
若确需方向提示，锥长必须与波前绑定：`lb = Math.min(r*0.55, 0.30)`
（写 `Math.min(r, 0.42)` 会随物体跑远拉成长斜线）。

### 4.4 圆弧张角必须与尺寸标注带联合约束

弧顶点高度 `$y_0 + r_{max}\sin\theta$` **必须小于最下方那条尺寸线的 y**。
否则弧线横穿尺寸标注、压住字母/数值（3× 特写才看得出）。

**双保险**：① `half` 收到 10°；② 对弧加硬裁剪 `yTop = W2S(0, Y_DIM1-0.02)`。

### 4.5 其他高频细节

- **极短矢量（<30 px）** 放不下行内标签 ⇒ **抬门限：短到读不出对应关系就不标**（面板已有数值）。
- **两个标签各自扫场** ⇒ 定位 A 时要同时检查与 B 的距离。
- **两条尺寸线共用端点** ⇒ 标签必须一个放线上方、一个放下方，垂直错开。
- **法线方向按屏幕坐标系推导**：世界方向 `(ux,uy)` ⇒ 世界坐标下的屏幕右法线 `(-uy, ux)`。用反了会镜像压住另一条线。
- **旋转矢量标签**：① 说明文字下铺白底让位；② 偏移按朝向取符号外推。
- **短箭头**不用压线白底标签（会盖掉箭头），放线下方。
- **`FIG.ground/wall` 的 `gap`/`hatchLen` 是世界长度**。**画墙+磁铁先画磁铁再画墙。**
- **圆弧段必须与物块用同一锚点**（否则衔接跳变）。**边界虚线要限长。**
- **`FIG.particle` 标签在球下方**，易与矢量/地面重叠。**`FIG.pendulum` 的 angle 向 +x 为正。**
- **竖排文字盒**：先量盒内净高像素，再定 `字号 ≤ 净高/(字数+1)`、
  步进 ≤ 字号×1.1，末字留 6 px 下边距 —— 否则末字被盒底截断
  （5 字「粒子发生器」用 13 px 必被切）。

---

## 五、公式渲染判据

### 5.1 `\frac` 不是禁忌，真凶是多行环境

实测 `\frac` 完全正常（`mjx-error=0`）；真正炸的是**多行环境 `\begin{aligned}`**。

### 5.2 `merror` 计数不可靠

```js
// ❌ 会匹配 assistive-MML 中正常公式自带的 <merror>，误判
document.querySelectorAll('merror').length

// ✅ 可靠判据
document.querySelectorAll('mjx-container.mjx-error, mjx-container[data-mjx-error]').length
```

### 5.3 MathJax 稳定检测

固定 `waitForTimeout(3500)` 在 1600 px + dpr2 下会假阴性。
**改为**：连续 6 次采样 `mjx-container` 数量不变且零 error 才算稳定。

### 5.4 横向溢出

解析栏在 1280 px 最紧 ⇒ 精简公式或追加 `<style id="tune-width">` 压 padding / 控宽。

---

## 六、探测与审计脚本陷阱

| 坑 | 症状 | 修法 |
|---|---|---|
| `browser.close()` 挂死 | 审计无输出直接结束 | `Promise.race([close, 6s])` 后**显式 `process.exit`**；每个 await 套超时；日志重定向到文件，不要 `| head` |
| `page.click()` 在重绘页挂起 | 脚手架假超时 | 用 `evaluate(id => getElementById(id).click())` |
| 测「下一步」前未 reset | 末段时看似按钮失效（假阳性） | 先 reset |
| 探针搜可能出现在注释里的串 | 假 FOUND / 假 MISSING | 先剥 JS 注释（块 + 行）再搜 |
| Python 里写含 `%` 的 CSS 片段 | `max-width:100%` 触发格式化报错 | 用 `.replace()`，不要 `%` 格式化 |
| 超长 `python -c` 内联 | 中文括号触发 "File name too long" | 写真实 `.py` 文件 |
| 用旧 `syntax_check.js` | Windows 必抛 `spawnSync … EBUSY` ⇒ 三段全报 `SYNTAX FAIL` 的**假阴性** | 用 `scripts/syntax_check.js`（`vm.Script` 同进程解析） |

---

## 七、脚本编写纪律

- **改生成器一次只发一条 Edit** —— 并发 Edit 会静默丢改动。
- 中文 stdout 经 PowerShell 会乱码，**页面本身没问题**；看数值与截图。
- 截图裁剪坐标要按真实像素换算：
  `s = im.size[0] / 1080.0`（整页 5100 px 宽却按 1080 显示坐标裁 ⇒ 全错）。

---

## 八、复检铁律

**同一道题重建 / 重跑，也必须重走 3× 人工看图**，不能因为「上次过门禁」跳过。

真实案例：某题重建时，波束边界斜虚线在 `t ≈ 3.0 s`（第二次发射刚发生、波前很薄）
横穿场景压住 `v` 箭头 —— 上次抽样的 7 个时刻**恰好没覆盖这段**所以漏检。

**抽样时刻必须覆盖「每个物理阶段的起始处」**，不能只取各阶段中点与末态。